const mysql = require('mysql2');
const config = require('./config');

// Create database connection
const db = mysql.createConnection({
  host: config.database.host,
  port: config.database.port,
  user: config.database.user,
  password: config.database.password
});

// Connect to MySQL server
db.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL server:', err);
    process.exit(1);
  }
  console.log('Connected to MySQL server');
});

// Create database if it doesn't exist
const createDatabaseQuery = `CREATE DATABASE IF NOT EXISTS ${config.database.database}`;
db.query(createDatabaseQuery, (err) => {
  if (err) {
    console.error('Error creating database:', err);
    process.exit(1);
  }
  console.log(`Database '${config.database.database}' is ready`);
});

// Switch to the gym_db database
db.query(`USE ${config.database.database}`, (err) => {
  if (err) {
    console.error('Error switching to database:', err);
    process.exit(1);
  }
  console.log(`Using database '${config.database.database}'`);
});

// Create users table
const createUsersTableQuery = `
  CREATE TABLE IF NOT EXISTS gym_signup (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  )
`;

db.query(createUsersTableQuery, (err) => {
  if (err) {
    console.error('Error creating users table:', err);
    process.exit(1);
  }
  console.log('Users table created successfully');
  
  // Close connection
  db.end((err) => {
    if (err) {
      console.error('Error closing database connection:', err);
    } else {
      console.log('Database setup completed successfully');
    }
  });
});
